export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function formatDateBR(isoDate: string): string {
  const [year, month, day] = isoDate.split('-');
  if (!year || !month || !day) return isoDate;
  return `${day}/${month}/${year}`;
}

export function isSameMonth(isoDate: string, reference = new Date()): boolean {
  const date = new Date(`${isoDate}T00:00:00`);
  return (
    date.getMonth() === reference.getMonth() &&
    date.getFullYear() === reference.getFullYear()
  );
}

export function monthLabel(monthIndex: number): string {
  const labels = [
    'Jan',
    'Fev',
    'Mar',
    'Abr',
    'Mai',
    'Jun',
    'Jul',
    'Ago',
    'Set',
    'Out',
    'Nov',
    'Dez',
  ];
  return labels[monthIndex] ?? '';
}

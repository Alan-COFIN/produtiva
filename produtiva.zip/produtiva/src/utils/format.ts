import type { ActivityCategory, ActivityStatus } from '../types/activity';

export function formatHours(hours: number): string {
  return `${hours.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}h`;
}

export const CATEGORY_LABELS: Record<ActivityCategory, string> = {
  financeiro: 'Financeiro',
  contratos: 'Contratos',
  processos: 'Processos',
  reuniao: 'Reunião',
  relatorio: 'Relatório',
  outro: 'Outro',
};

export const STATUS_LABELS: Record<ActivityStatus, string> = {
  pendente: 'Pendente',
  em_andamento: 'Em andamento',
  concluida: 'Concluída',
};

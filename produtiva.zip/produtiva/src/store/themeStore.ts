import { create } from 'zustand';
import { localStorageDriver } from '../storage/localStorage';
import type { Theme } from '../types/common';

const THEME_STORAGE_KEY = 'produtiva:theme';

function getInitialTheme(): Theme {
  const stored = localStorageDriver.get<Theme>(THEME_STORAGE_KEY);
  if (stored) return stored;
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  return prefersDark ? 'dark' : 'light';
}

function applyThemeToDocument(theme: Theme): void {
  document.documentElement.classList.toggle('dark', theme === 'dark');
}

interface ThemeState {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
}

export const useThemeStore = create<ThemeState>((set, get) => ({
  theme: getInitialTheme(),

  toggleTheme: () => {
    const next: Theme = get().theme === 'light' ? 'dark' : 'light';
    get().setTheme(next);
  },

  setTheme: (theme: Theme) => {
    applyThemeToDocument(theme);
    localStorageDriver.set(THEME_STORAGE_KEY, theme);
    set({ theme });
  },
}));

// Apply the resolved theme immediately on module load, before first paint.
applyThemeToDocument(useThemeStore.getState().theme);

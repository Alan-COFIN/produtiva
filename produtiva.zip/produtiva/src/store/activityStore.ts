import { create } from 'zustand';
import { activityService } from '../services/activityService';
import type { Activity, ActivityInput } from '../types/activity';

interface ActivityState {
  activities: Activity[];
  addActivity: (input: ActivityInput) => void;
  updateActivity: (id: string, input: ActivityInput) => void;
  removeActivity: (id: string) => void;
}

export const useActivityStore = create<ActivityState>((set) => ({
  activities: activityService.list(),

  addActivity: (input) => {
    activityService.create(input);
    set({ activities: activityService.list() });
  },

  updateActivity: (id, input) => {
    activityService.update(id, input);
    set({ activities: activityService.list() });
  },

  removeActivity: (id) => {
    activityService.remove(id);
    set({ activities: activityService.list() });
  },
}));

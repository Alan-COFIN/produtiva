export type Theme = 'light' | 'dark';

export interface SelectOption<T = string> {
  label: string;
  value: T;
}

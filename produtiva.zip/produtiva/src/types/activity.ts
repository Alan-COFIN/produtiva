export type ActivityCategory =
  | 'financeiro'
  | 'contratos'
  | 'processos'
  | 'reuniao'
  | 'relatorio'
  | 'outro';

export type ActivityStatus = 'pendente' | 'em_andamento' | 'concluida';

export interface Activity {
  id: string;
  title: string;
  description?: string;
  category: ActivityCategory;
  status: ActivityStatus;
  hours: number;
  date: string; // ISO date (yyyy-mm-dd)
  createdAt: string;
  updatedAt: string;
}

export type ActivityInput = Omit<Activity, 'id' | 'createdAt' | 'updatedAt'>;

export interface ActivityFilters {
  search: string;
  category: ActivityCategory | 'todas';
  status: ActivityStatus | 'todos';
}

import { ComingSoon } from '../../components/ui/ComingSoon';

export function IndicatorsPage() {
  return <ComingSoon title="Indicadores" />;
}

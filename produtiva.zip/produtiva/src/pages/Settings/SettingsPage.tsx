import { Card } from '../../components/ui/Card';
import { useThemeStore } from '../../store/themeStore';

export function SettingsPage() {
  const { theme, setTheme } = useThemeStore();

  return (
    <div className="flex max-w-xl flex-col gap-4">
      <Card>
        <h2 className="mb-1 text-sm font-semibold text-text-primary">Aparência</h2>
        <p className="mb-4 text-sm text-text-secondary">
          Escolha entre o tema claro ou escuro para a interface.
        </p>
        <div className="flex gap-2">
          <button
            onClick={() => setTheme('light')}
            className={`rounded-lg border px-4 py-2 text-sm font-medium ${
              theme === 'light'
                ? 'border-accent bg-accent-subtle text-accent'
                : 'border-border text-text-secondary hover:bg-surface-hover'
            }`}
          >
            Claro
          </button>
          <button
            onClick={() => setTheme('dark')}
            className={`rounded-lg border px-4 py-2 text-sm font-medium ${
              theme === 'dark'
                ? 'border-accent bg-accent-subtle text-accent'
                : 'border-border text-text-secondary hover:bg-surface-hover'
            }`}
          >
            Escuro
          </button>
        </div>
      </Card>
    </div>
  );
}

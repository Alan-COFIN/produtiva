import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PlusIcon } from '@heroicons/react/24/outline';
import { Button } from '../../components/ui/Button';
import { ActivityModal } from './components/ActivityModal';
import { ActivityFiltersBar } from './components/ActivityFiltersBar';
import { ActivityList } from './components/ActivityList';
import { ConfirmDeleteDialog } from './components/ConfirmDeleteDialog';
import { useActivityFilters } from '../../hooks/useActivityFilters';
import { useActivityStore } from '../../store/activityStore';
import type { ActivityFormValues } from './activitySchema';
import type { Activity } from '../../types/activity';

export function ActivitiesPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { addActivity, updateActivity, removeActivity } = useActivityStore();
  const { filters, setFilters, filteredActivities } = useActivityFilters();

  const [editingActivity, setEditingActivity] = useState<Activity | undefined>();
  const [isModalOpen, setIsModalOpen] = useState(searchParams.get('nova') === '1');
  const [activityToDelete, setActivityToDelete] = useState<Activity | undefined>();

  function closeModal() {
    setIsModalOpen(false);
    setEditingActivity(undefined);
    if (searchParams.get('nova')) {
      searchParams.delete('nova');
      setSearchParams(searchParams, { replace: true });
    }
  }

  function handleCreateClick() {
    setEditingActivity(undefined);
    setIsModalOpen(true);
  }

  function handleEditClick(activity: Activity) {
    setEditingActivity(activity);
    setIsModalOpen(true);
  }

  function handleSubmit(values: ActivityFormValues) {
    if (editingActivity) {
      updateActivity(editingActivity.id, values);
    } else {
      addActivity(values);
    }
    closeModal();
  }

  function handleConfirmDelete() {
    if (activityToDelete) {
      removeActivity(activityToDelete.id);
      setActivityToDelete(undefined);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <ActivityFiltersBar filters={filters} onChange={setFilters} />
        <Button onClick={handleCreateClick} className="ml-3 shrink-0">
          <PlusIcon className="h-4 w-4" />
          Nova atividade
        </Button>
      </div>

      <ActivityList
        activities={filteredActivities}
        onEdit={handleEditClick}
        onDelete={setActivityToDelete}
      />

      <ActivityModal
        isOpen={isModalOpen}
        activity={editingActivity}
        onClose={closeModal}
        onSubmit={handleSubmit}
      />

      <ConfirmDeleteDialog
        isOpen={Boolean(activityToDelete)}
        activityTitle={activityToDelete?.title}
        onCancel={() => setActivityToDelete(undefined)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}

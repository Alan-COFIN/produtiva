import { z } from 'zod';

export const activityFormSchema = z.object({
  title: z.string().trim().min(3, 'Informe um título com pelo menos 3 caracteres'),
  description: z.string().trim().optional(),
  category: z.enum([
    'financeiro',
    'contratos',
    'processos',
    'reuniao',
    'relatorio',
    'outro',
  ]),
  status: z.enum(['pendente', 'em_andamento', 'concluida']),
  hours: z.coerce.number().positive('Informe um número de horas maior que zero'),
  date: z.string().min(1, 'Informe a data'),
});

// Input: what the form fields hold before parsing (hours may be a raw string).
export type ActivityFormInput = z.input<typeof activityFormSchema>;
// Output: what we get after zod parses/coerces the input (hours is a number).
export type ActivityFormValues = z.output<typeof activityFormSchema>;

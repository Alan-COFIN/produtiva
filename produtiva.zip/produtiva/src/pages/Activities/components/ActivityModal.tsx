import { Modal } from '../../../components/ui/Modal';
import { ActivityForm } from './ActivityForm';
import type { ActivityFormValues } from '../activitySchema';
import type { Activity } from '../../../types/activity';

interface ActivityModalProps {
  isOpen: boolean;
  activity?: Activity;
  onClose: () => void;
  onSubmit: (values: ActivityFormValues) => void;
}

export function ActivityModal({
  isOpen,
  activity,
  onClose,
  onSubmit,
}: ActivityModalProps) {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={activity ? 'Editar atividade' : 'Nova atividade'}
    >
      <ActivityForm initialValues={activity} onSubmit={onSubmit} onCancel={onClose} />
    </Modal>
  );
}

import { Modal } from '../../../components/ui/Modal';
import { Button } from '../../../components/ui/Button';

interface ConfirmDeleteDialogProps {
  isOpen: boolean;
  activityTitle?: string;
  onCancel: () => void;
  onConfirm: () => void;
}

export function ConfirmDeleteDialog({
  isOpen,
  activityTitle,
  onCancel,
  onConfirm,
}: ConfirmDeleteDialogProps) {
  return (
    <Modal isOpen={isOpen} onClose={onCancel} title="Excluir atividade">
      <p className="text-sm text-text-secondary">
        Tem certeza que deseja excluir{' '}
        <span className="font-medium text-text-primary">
          {activityTitle ?? 'esta atividade'}
        </span>
        ? Esta ação não pode ser desfeita.
      </p>
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button variant="danger" onClick={onConfirm}>
          Excluir
        </Button>
      </div>
    </Modal>
  );
}

import { PencilIcon, TrashIcon } from '@heroicons/react/24/outline';
import { Card } from '../../../components/ui/Card';
import { Badge } from '../../../components/ui/Badge';
import { EmptyState } from '../../../components/ui/EmptyState';
import { formatDateBR } from '../../../utils/date';
import { CATEGORY_LABELS, STATUS_LABELS, formatHours } from '../../../utils/format';
import type { Activity } from '../../../types/activity';

interface ActivityListProps {
  activities: Activity[];
  onEdit: (activity: Activity) => void;
  onDelete: (activity: Activity) => void;
}

const STATUS_TONE = {
  pendente: 'warning',
  em_andamento: 'accent',
  concluida: 'success',
} as const;

export function ActivityList({ activities, onEdit, onDelete }: ActivityListProps) {
  if (activities.length === 0) {
    return (
      <EmptyState
        title="Nenhuma atividade encontrada"
        description="Ajuste os filtros ou cadastre uma nova atividade."
      />
    );
  }

  return (
    <Card className="p-0">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border text-left text-xs text-text-secondary">
            <th className="px-5 py-3 font-medium">Título</th>
            <th className="px-5 py-3 font-medium">Categoria</th>
            <th className="px-5 py-3 font-medium">Status</th>
            <th className="px-5 py-3 font-medium">Horas</th>
            <th className="px-5 py-3 font-medium">Data</th>
            <th className="px-5 py-3 font-medium text-right">Ações</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {activities.map((activity) => (
            <tr key={activity.id} className="hover:bg-surface-hover">
              <td className="px-5 py-3">
                <p className="font-medium text-text-primary">{activity.title}</p>
                {activity.description && (
                  <p className="text-xs text-text-secondary">{activity.description}</p>
                )}
              </td>
              <td className="px-5 py-3 text-text-secondary">
                {CATEGORY_LABELS[activity.category]}
              </td>
              <td className="px-5 py-3">
                <Badge tone={STATUS_TONE[activity.status]}>
                  {STATUS_LABELS[activity.status]}
                </Badge>
              </td>
              <td className="px-5 py-3 text-text-secondary">
                {formatHours(activity.hours)}
              </td>
              <td className="px-5 py-3 text-text-secondary">
                {formatDateBR(activity.date)}
              </td>
              <td className="px-5 py-3">
                <div className="flex justify-end gap-1">
                  <button
                    onClick={() => onEdit(activity)}
                    aria-label="Editar atividade"
                    className="rounded-md p-1.5 text-text-secondary hover:bg-surface hover:text-accent"
                  >
                    <PencilIcon className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onDelete(activity)}
                    aria-label="Excluir atividade"
                    className="rounded-md p-1.5 text-text-secondary hover:bg-surface hover:text-danger"
                  >
                    <TrashIcon className="h-4 w-4" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
}

import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import { Input } from '../../../components/ui/Input';
import { Select } from '../../../components/ui/Select';
import { CATEGORY_LABELS, STATUS_LABELS } from '../../../utils/format';
import type { ActivityFilters } from '../../../types/activity';

interface ActivityFiltersBarProps {
  filters: ActivityFilters;
  onChange: (filters: ActivityFilters) => void;
}

const CATEGORY_FILTER_OPTIONS = [
  { value: 'todas', label: 'Todas as categorias' },
  ...Object.entries(CATEGORY_LABELS).map(([value, label]) => ({ value, label })),
];

const STATUS_FILTER_OPTIONS = [
  { value: 'todos', label: 'Todos os status' },
  ...Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label })),
];

export function ActivityFiltersBar({ filters, onChange }: ActivityFiltersBarProps) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
      <div className="relative flex-1">
        <MagnifyingGlassIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-text-muted" />
        <Input
          placeholder="Buscar atividade por título..."
          className="pl-9"
          value={filters.search}
          onChange={(event) => onChange({ ...filters, search: event.target.value })}
        />
      </div>

      <Select
        className="sm:w-56"
        options={CATEGORY_FILTER_OPTIONS}
        value={filters.category}
        onChange={(event) =>
          onChange({
            ...filters,
            category: event.target.value as ActivityFilters['category'],
          })
        }
      />

      <Select
        className="sm:w-48"
        options={STATUS_FILTER_OPTIONS}
        value={filters.status}
        onChange={(event) =>
          onChange({
            ...filters,
            status: event.target.value as ActivityFilters['status'],
          })
        }
      />
    </div>
  );
}

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Input } from '../../../components/ui/Input';
import { Select } from '../../../components/ui/Select';
import { Button } from '../../../components/ui/Button';
import { CATEGORY_LABELS, STATUS_LABELS } from '../../../utils/format';
import { todayISO } from '../../../utils/date';
import {
  activityFormSchema,
  type ActivityFormInput,
  type ActivityFormValues,
} from '../activitySchema';
import type { Activity } from '../../../types/activity';

interface ActivityFormProps {
  initialValues?: Activity;
  onSubmit: (values: ActivityFormValues) => void;
  onCancel: () => void;
}

const CATEGORY_OPTIONS = Object.entries(CATEGORY_LABELS).map(([value, label]) => ({
  value,
  label,
}));

const STATUS_OPTIONS = Object.entries(STATUS_LABELS).map(([value, label]) => ({
  value,
  label,
}));

export function ActivityForm({ initialValues, onSubmit, onCancel }: ActivityFormProps) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ActivityFormInput, unknown, ActivityFormValues>({
    resolver: zodResolver(activityFormSchema),
    defaultValues: initialValues ?? {
      title: '',
      description: '',
      category: 'outro',
      status: 'pendente',
      hours: 1,
      date: todayISO(),
    },
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
      <Input
        id="title"
        label="Título"
        placeholder="Ex: Conciliação bancária de junho"
        error={errors.title?.message}
        {...register('title')}
      />

      <Input
        id="description"
        label="Descrição (opcional)"
        placeholder="Detalhes adicionais"
        error={errors.description?.message}
        {...register('description')}
      />

      <div className="grid grid-cols-2 gap-4">
        <Select
          id="category"
          label="Categoria"
          options={CATEGORY_OPTIONS}
          error={errors.category?.message}
          {...register('category')}
        />
        <Select
          id="status"
          label="Status"
          options={STATUS_OPTIONS}
          error={errors.status?.message}
          {...register('status')}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          id="hours"
          type="number"
          step="0.5"
          min="0"
          label="Horas"
          error={errors.hours?.message}
          {...register('hours')}
        />
        <Input
          id="date"
          type="date"
          label="Data"
          error={errors.date?.message}
          {...register('date')}
        />
      </div>

      <div className="mt-2 flex justify-end gap-2">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {initialValues ? 'Salvar alterações' : 'Criar atividade'}
        </Button>
      </div>
    </form>
  );
}

import { ComingSoon } from '../../components/ui/ComingSoon';

export function ReportsPage() {
  return <ComingSoon title="Relatórios" />;
}

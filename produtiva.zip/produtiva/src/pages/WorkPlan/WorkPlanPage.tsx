import { ComingSoon } from '../../components/ui/ComingSoon';

export function WorkPlanPage() {
  return <ComingSoon title="Plano de Trabalho" />;
}

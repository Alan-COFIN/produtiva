import {
  ClockIcon,
  FlagIcon,
  ExclamationCircleIcon,
  ClipboardDocumentListIcon,
} from '@heroicons/react/24/outline';
import { StatCard } from './components/StatCard';
import { HoursChart } from './components/HoursChart';
import { RecentActivities } from './components/RecentActivities';
import { QuickActions } from './components/QuickActions';
import { useDashboardStats } from '../../hooks/useDashboardStats';
import { formatHours } from '../../utils/format';

export function DashboardPage() {
  const stats = useDashboardStats();

  return (
    <div className="flex flex-col gap-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Horas do mês"
          value={formatHours(stats.monthHours)}
          icon={ClockIcon}
          hint={`Meta: ${formatHours(stats.goal)}`}
        />
        <StatCard
          label="Meta atingida"
          value={`${stats.goalProgress}%`}
          icon={FlagIcon}
        />
        <StatCard
          label="Pendências"
          value={String(stats.pendingCount)}
          icon={ExclamationCircleIcon}
        />
        <StatCard
          label="Atividades"
          value={String(stats.totalActivities)}
          icon={ClipboardDocumentListIcon}
        />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <HoursChart data={stats.monthlyHoursSeries} />
        </div>
        <QuickActions />
      </div>

      <RecentActivities activities={stats.recentActivities} />
    </div>
  );
}

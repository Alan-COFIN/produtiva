import { useNavigate } from 'react-router-dom';
import { PlusIcon, FolderIcon, ChartBarIcon } from '@heroicons/react/24/outline';
import { Card } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';

export function QuickActions() {
  const navigate = useNavigate();

  return (
    <Card>
      <h3 className="mb-4 text-sm font-semibold text-text-primary">Ações rápidas</h3>
      <div className="flex flex-col gap-2">
        <Button
          variant="secondary"
          className="justify-start"
          onClick={() => navigate('/atividades?nova=1')}
        >
          <PlusIcon className="h-4 w-4" />
          Nova atividade
        </Button>
        <Button
          variant="secondary"
          className="justify-start"
          onClick={() => navigate('/relatorios')}
        >
          <FolderIcon className="h-4 w-4" />
          Ver relatórios
        </Button>
        <Button
          variant="secondary"
          className="justify-start"
          onClick={() => navigate('/indicadores')}
        >
          <ChartBarIcon className="h-4 w-4" />
          Ver indicadores
        </Button>
      </div>
    </Card>
  );
}

import type { ComponentType, SVGProps } from 'react';
import { Card } from '../../../components/ui/Card';

interface StatCardProps {
  label: string;
  value: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
  hint?: string;
}

export function StatCard({ label, value, icon: Icon, hint }: StatCardProps) {
  return (
    <Card className="flex items-start justify-between">
      <div>
        <p className="text-sm text-text-secondary">{label}</p>
        <p className="mt-2 text-2xl font-semibold text-text-primary">{value}</p>
        {hint && <p className="mt-1 text-xs text-text-muted">{hint}</p>}
      </div>
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent-subtle text-accent">
        <Icon className="h-5 w-5" />
      </div>
    </Card>
  );
}

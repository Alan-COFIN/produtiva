import { Card } from '../../../components/ui/Card';
import { Badge } from '../../../components/ui/Badge';
import { EmptyState } from '../../../components/ui/EmptyState';
import { formatDateBR } from '../../../utils/date';
import { CATEGORY_LABELS, formatHours } from '../../../utils/format';
import type { Activity } from '../../../types/activity';

interface RecentActivitiesProps {
  activities: Activity[];
}

const STATUS_TONE = {
  pendente: 'warning',
  em_andamento: 'accent',
  concluida: 'success',
} as const;

export function RecentActivities({ activities }: RecentActivitiesProps) {
  return (
    <Card>
      <h3 className="mb-4 text-sm font-semibold text-text-primary">
        Últimas atividades
      </h3>

      {activities.length === 0 ? (
        <EmptyState
          title="Nenhuma atividade registrada"
          description="Cadastre sua primeira atividade para vê-la aqui."
        />
      ) : (
        <ul className="flex flex-col divide-y divide-border">
          {activities.map((activity) => (
            <li key={activity.id} className="flex items-center justify-between py-3">
              <div>
                <p className="text-sm font-medium text-text-primary">
                  {activity.title}
                </p>
                <p className="text-xs text-text-secondary">
                  {CATEGORY_LABELS[activity.category]} · {formatDateBR(activity.date)}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-text-secondary">
                  {formatHours(activity.hours)}
                </span>
                <Badge tone={STATUS_TONE[activity.status]}>
                  {activity.status === 'em_andamento'
                    ? 'Em andamento'
                    : activity.status === 'concluida'
                      ? 'Concluída'
                      : 'Pendente'}
                </Badge>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

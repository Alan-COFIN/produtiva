import { SunIcon, MoonIcon } from '@heroicons/react/24/outline';
import { useThemeStore } from '../store/themeStore';

interface NavbarProps {
  title: string;
}

export function Navbar({ title }: NavbarProps) {
  const { theme, toggleTheme } = useThemeStore();

  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-surface px-8">
      <h1 className="text-lg font-semibold text-text-primary">{title}</h1>

      <button
        onClick={toggleTheme}
        aria-label="Alternar tema"
        className="flex h-9 w-9 items-center justify-center rounded-lg border border-border text-text-secondary hover:bg-surface-hover"
      >
        {theme === 'light' ? (
          <MoonIcon className="h-5 w-5" />
        ) : (
          <SunIcon className="h-5 w-5" />
        )}
      </button>
    </header>
  );
}

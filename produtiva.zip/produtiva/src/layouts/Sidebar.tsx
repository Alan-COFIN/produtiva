import { NavLink } from 'react-router-dom';
import {
  HomeIcon,
  PencilSquareIcon,
  CalendarDaysIcon,
  ChartBarIcon,
  FolderIcon,
  Cog6ToothIcon,
} from '@heroicons/react/24/outline';

interface NavItem {
  label: string;
  to: string;
  icon: typeof HomeIcon;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Dashboard', to: '/', icon: HomeIcon },
  { label: 'Atividades', to: '/atividades', icon: PencilSquareIcon },
  { label: 'Plano de Trabalho', to: '/plano-de-trabalho', icon: CalendarDaysIcon },
  { label: 'Indicadores', to: '/indicadores', icon: ChartBarIcon },
  { label: 'Relatórios', to: '/relatorios', icon: FolderIcon },
  { label: 'Configurações', to: '/configuracoes', icon: Cog6ToothIcon },
];

export function Sidebar() {
  return (
    <aside className="flex h-screen w-64 flex-col border-r border-border bg-surface px-4 py-6">
      <div className="mb-8 flex items-center gap-2 px-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-sm font-bold text-white">
          P
        </div>
        <span className="text-base font-semibold text-text-primary">Produtiva</span>
      </div>

      <nav className="flex flex-1 flex-col gap-1">
        {NAV_ITEMS.map(({ label, to, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-accent-subtle text-accent'
                  : 'text-text-secondary hover:bg-surface-hover hover:text-text-primary'
              }`
            }
          >
            <Icon className="h-5 w-5" />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="rounded-lg border border-border px-3 py-2 text-xs text-text-muted">
        Módulo PGD · v0.1.0
      </div>
    </aside>
  );
}

/**
 * Thin wrapper around window.localStorage.
 * Isolating storage access here means the persistence strategy
 * (e.g. swapping to a REST API) can change without touching callers.
 */
export const localStorageDriver = {
  get<T>(key: string): T | null {
    try {
      const raw = window.localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : null;
    } catch {
      return null;
    }
  },

  set<T>(key: string, value: T): void {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Storage may be unavailable (private mode, quota exceeded, etc.)
      // Failing silently keeps the UI usable; callers treat writes as best-effort.
    }
  },

  remove(key: string): void {
    try {
      window.localStorage.removeItem(key);
    } catch {
      // no-op
    }
  },
};

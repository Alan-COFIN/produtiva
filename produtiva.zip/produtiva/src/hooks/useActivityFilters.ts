import { useMemo, useState } from 'react';
import { useActivityStore } from '../store/activityStore';
import type { ActivityFilters } from '../types/activity';

const DEFAULT_FILTERS: ActivityFilters = {
  search: '',
  category: 'todas',
  status: 'todos',
};

export function useActivityFilters() {
  const activities = useActivityStore((state) => state.activities);
  const [filters, setFilters] = useState<ActivityFilters>(DEFAULT_FILTERS);

  const filteredActivities = useMemo(() => {
    const search = filters.search.trim().toLowerCase();

    return activities.filter((activity) => {
      const matchesSearch =
        search.length === 0 || activity.title.toLowerCase().includes(search);
      const matchesCategory =
        filters.category === 'todas' || activity.category === filters.category;
      const matchesStatus =
        filters.status === 'todos' || activity.status === filters.status;

      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [activities, filters]);

  return { filters, setFilters, filteredActivities };
}

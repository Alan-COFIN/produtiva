import { useLocation } from 'react-router-dom';

const ROUTE_TITLES: Record<string, string> = {
  '/': 'Dashboard',
  '/atividades': 'Atividades',
  '/plano-de-trabalho': 'Plano de Trabalho',
  '/indicadores': 'Indicadores',
  '/relatorios': 'Relatórios',
  '/configuracoes': 'Configurações',
};

export function usePageTitle(): string {
  const { pathname } = useLocation();
  return ROUTE_TITLES[pathname] ?? 'Produtiva';
}

import { useMemo } from 'react';
import { useActivityStore } from '../store/activityStore';
import { isSameMonth, monthLabel } from '../utils/date';

const MONTHLY_HOURS_GOAL = 160;

export interface MonthlyHoursPoint {
  month: string;
  horas: number;
}

export interface DashboardStats {
  monthHours: number;
  goal: number;
  goalProgress: number;
  pendingCount: number;
  totalActivities: number;
  monthlyHoursSeries: MonthlyHoursPoint[];
  recentActivities: ReturnType<typeof useActivityStore.getState>['activities'];
}

export function useDashboardStats(): DashboardStats {
  const activities = useActivityStore((state) => state.activities);

  return useMemo(() => {
    const monthActivities = activities.filter((activity) =>
      isSameMonth(activity.date),
    );
    const monthHours = monthActivities.reduce((sum, a) => sum + a.hours, 0);
    const pendingCount = activities.filter(
      (activity) => activity.status !== 'concluida',
    ).length;

    const now = new Date();
    const monthlyHoursSeries: MonthlyHoursPoint[] = Array.from({ length: 6 }).map(
      (_, index) => {
        const reference = new Date(now.getFullYear(), now.getMonth() - (5 - index), 1);
        const hours = activities
          .filter((activity) => isSameMonth(activity.date, reference))
          .reduce((sum, a) => sum + a.hours, 0);
        return { month: monthLabel(reference.getMonth()), horas: hours };
      },
    );

    const recentActivities = [...activities]
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, 5);

    return {
      monthHours,
      goal: MONTHLY_HOURS_GOAL,
      goalProgress: Math.min(100, Math.round((monthHours / MONTHLY_HOURS_GOAL) * 100)),
      pendingCount,
      totalActivities: activities.length,
      monthlyHoursSeries,
      recentActivities,
    };
  }, [activities]);
}

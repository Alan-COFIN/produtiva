import { createBrowserRouter } from 'react-router-dom';
import { MainLayout } from '../layouts/MainLayout';
import { DashboardPage } from '../pages/Dashboard/DashboardPage';
import { ActivitiesPage } from '../pages/Activities/ActivitiesPage';
import { WorkPlanPage } from '../pages/WorkPlan/WorkPlanPage';
import { IndicatorsPage } from '../pages/Indicators/IndicatorsPage';
import { ReportsPage } from '../pages/Reports/ReportsPage';
import { SettingsPage } from '../pages/Settings/SettingsPage';

export const router = createBrowserRouter(
  [
    {
      path: '/',
      element: <MainLayout />,
      children: [
        { index: true, element: <DashboardPage /> },
        { path: 'atividades', element: <ActivitiesPage /> },
        { path: 'plano-de-trabalho', element: <WorkPlanPage /> },
        { path: 'indicadores', element: <IndicatorsPage /> },
        { path: 'relatorios', element: <ReportsPage /> },
        { path: 'configuracoes', element: <SettingsPage /> },
      ],
    },
  ],
  { basename: import.meta.env.BASE_URL },
);

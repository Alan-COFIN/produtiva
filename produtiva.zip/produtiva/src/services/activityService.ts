import { localStorageDriver } from '../storage/localStorage';
import { generateId } from '../utils/id';
import type { Activity, ActivityInput } from '../types/activity';

const ACTIVITIES_STORAGE_KEY = 'produtiva:activities';

function nowISO(): string {
  return new Date().toISOString();
}

export const activityService = {
  list(): Activity[] {
    return localStorageDriver.get<Activity[]>(ACTIVITIES_STORAGE_KEY) ?? [];
  },

  create(input: ActivityInput): Activity {
    const activity: Activity = {
      ...input,
      id: generateId(),
      createdAt: nowISO(),
      updatedAt: nowISO(),
    };
    const activities = [activity, ...this.list()];
    localStorageDriver.set(ACTIVITIES_STORAGE_KEY, activities);
    return activity;
  },

  update(id: string, input: ActivityInput): Activity | null {
    const activities = this.list();
    const index = activities.findIndex((activity) => activity.id === id);
    if (index === -1) return null;

    const updated: Activity = {
      ...activities[index],
      ...input,
      updatedAt: nowISO(),
    };
    activities[index] = updated;
    localStorageDriver.set(ACTIVITIES_STORAGE_KEY, activities);
    return updated;
  },

  remove(id: string): void {
    const activities = this.list().filter((activity) => activity.id !== id);
    localStorageDriver.set(ACTIVITIES_STORAGE_KEY, activities);
  },
};
